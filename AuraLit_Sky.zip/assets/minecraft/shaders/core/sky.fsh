#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec3 skyRay;
in float skyFlag;

out vec4 fragColor;

void main() {

    if (skyFlag > 0.5) {
        if (!gl_FrontFacing) discard;
        fragColor = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }

    fragColor = apply_fog(ColorModulator, sphericalVertexDistance, cylindricalVertexDistance, 0.0, FogSkyEnd, FogSkyEnd, FogSkyEnd, FogColor);
}
