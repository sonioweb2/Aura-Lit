#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;

void main() {
    // Hidden: the picture has its own sky. (Outside the clip volume, so nothing is drawn.)
    gl_Position = vec4(2.0, 2.0, 2.0, 1.0) + 0.0 * ProjMat * ModelViewMat * vec4(Position, 1.0);
}
